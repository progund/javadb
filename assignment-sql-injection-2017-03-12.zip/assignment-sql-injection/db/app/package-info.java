/**
 * This package contains all the classes for the JDBC exercise. In normal cases, we'd have a lot more packages. It would be natural, for instance, to separate the domain objects, such as Municipality from the storage classes (the ones dealing with persistance).
 */
package db.app;
