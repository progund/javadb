package db.main;

import db.app.*;

public class Main {
  
  public static void main(String[] args) {
    MunicipalityDB db = new MyMunicipalities();
    /* Add statements below here as per the instructions for handin 03 */
    
  }
}
