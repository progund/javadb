/**
 * This package exists only to provide a separate namespace and location for the Main application.
 */
